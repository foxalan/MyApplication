package com.example.mybulter.view.inter;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 21/7/17$
 * Input Parameter &
 */

public interface RegisterView {
    void setSuccess();

    void setFailed();

    void incomplete_information();

    void identity_error();

    void setUserExits();
}

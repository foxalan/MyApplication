package com.example.mybulter.model.impl;

import com.example.mybulter.model.inter.ProveModel;
import com.example.mybulter.presenter.inter.OnPorveFinishedListener;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 25/7/17$
 * Input Parameter &
 */

public class ProveModelImpl implements ProveModel {

    @Override
    public void getProveResult(String phone, String new_password, String identify_code, OnPorveFinishedListener onPorveFinishedListener) {

    }


}

package com.example.mybulter.view.inter;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 25/7/17$
 * Input Parameter &
 */

public interface ProveMessageView {

    void passwordNull();

    void passwordDifferent();

    void phoneNumberNull();

    void phoneNumberNotStandard();

    void identifyCodeError();

    void proveFail();

    void proveSuccess();


}

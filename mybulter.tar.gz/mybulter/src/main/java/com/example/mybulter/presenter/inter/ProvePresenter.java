package com.example.mybulter.presenter.inter;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 25/7/17$
 * Input Parameter &
 */

public interface ProvePresenter {

    void prove(String phone,String new_password,String new_password_again,String identify_code);
}

package com.example.mybulter.util;

import android.util.Log;

/**
 * Function Name : SetAudioMute
 * Author : Eddie
 * Modify Date :
 * Input Parameter &
 */

public class L {

    private static String name = "TANG";

    public static void d(String str){
        Log.d(name,str);
    }


}

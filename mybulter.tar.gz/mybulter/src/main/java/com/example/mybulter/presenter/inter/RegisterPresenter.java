package com.example.mybulter.presenter.inter;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 21/7/17$
 * Input Parameter &
 */

public interface RegisterPresenter {
    void register(String username,String password,boolean isIdentify);
}

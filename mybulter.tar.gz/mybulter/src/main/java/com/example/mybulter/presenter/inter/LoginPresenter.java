package com.example.mybulter.presenter.inter;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 21/7/17$
 * Input Parameter &
 */

public interface LoginPresenter {

    void startLogin(String username, String password);

    void onDestory();
}

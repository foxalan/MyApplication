package com.example.mybulter.Application;

import android.app.Application;
import android.content.Context;

import com.example.mybulter.constant.Constant;
import com.tencent.bugly.crashreport.CrashReport;

import cn.bmob.v3.Bmob;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 19/7/17$
 * Input Parameter &
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        CrashReport.initCrashReport(getApplicationContext(), "f1177e1a26", true);

        Bmob.initialize(this, Constant.BMOB_APP_ID);

    }


}

package com.example.mybulter.view.inter;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 21/7/17$
 * Input Parameter &
 */

public interface LoginView {



    void setUsernameError();

    void setPasswordError();

    void navigateToHome();

    void setSuccess();

    void setContentNull();


}

package com.example.mybulter.constant;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 20/7/17$
 * Input Parameter &
 */

public class Constant {
    public static final int MSG_GUIDE = 0x123;
    public static final int MSG_HOME = 0X124;

    public static int LIST_TYPE_ROBOT = 1;
    public int List_TYPE_HUMEN = 2;

    public static final String BMOB_APP_ID = "2a918f5aecd6ef04a8c05b24528a6e49";
    public static final String USER_NAME = "user_name";
    public static final String PASSWORD ="password";
    public static final String ISREMBER = "is_rem";

}

package com.example.mybulter.fragment;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.mybulter.R;
import com.example.mybulter.info.ChatInfo;
import com.example.mybulter.info.Type;
import com.example.mybulter.util.TimeUtil;
import com.example.mybulter.adapter.ChatAdapter;

import java.util.ArrayList;
import java.util.List;


public class ChatFragment extends Fragment {

    private ListView lv_chat;
    private ChatAdapter adapter;

    private EditText et_chat;
    private Button bt_send;

    private List<ChatInfo> chatInfoList = new ArrayList<>();

    private static final int TYPE_ROBOT = 0;
    private static final int TYPE_HUMAN = 1;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, null);

        initView(view);
        initData();
        initEvent();

        return view;
    }

    private void initView(View view) {
        lv_chat = (ListView) view.findViewById(R.id.lv_chat);
        et_chat = (EditText) view.findViewById(R.id.et_chat);
        bt_send = (Button) view.findViewById(R.id.bt_chat_send);

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initData() {
        chatInfoList.clear();

        String content = "你好,我是智能机器人小莫,非常高兴为你服务";
        String data = TimeUtil.getCurrentTimeS();
       // int type = TYPE_ROBOT;
        Type type = Type.ROBOT;
        ChatInfo chatInfo = new ChatInfo(content, data, type);
        chatInfoList.add(chatInfo);

    }

    private void initEvent() {
        adapter = new ChatAdapter(getActivity(), chatInfoList);

        lv_chat.setAdapter(adapter);

        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_chat.getText().equals("")) {
                    return;
                }

                initUserContent();
                lv_chat.smoothScrollToPosition(chatInfoList.size() - 1);

                et_chat.setText("");

            }
        });


    }

    private void initUserContent() {

        String user_content = et_chat.getText().toString();
        String user_data = TimeUtil.getCurrentTimeS();
        Type user_type = Type.HUMAN;

        ChatInfo chatInfo = new ChatInfo(user_content, user_data, user_type);
        chatInfoList.add(chatInfo);

        adapter.notifyDataSetChanged();
        lv_chat.getChildAt(chatInfoList.size() - 1);


    }
}

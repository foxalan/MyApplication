package com.example.mybulter.info;

/**
 * Function Name : TODO
 * Author : Alan
 * Modify Date : 21/7/17$
 * Input Parameter &
 */

public enum Type {
    ROBOT,HUMAN
}
